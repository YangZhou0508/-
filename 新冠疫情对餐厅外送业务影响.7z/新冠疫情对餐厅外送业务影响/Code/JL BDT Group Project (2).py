# Databricks notebook source
# DBTITLE 1,Big Data Tools 2 2021 : Group Project
# Project Goal: Using the available data from yelp, build a prediction model to predict which businesses will start doing delivery/takeout after the first lockdown.

# Team Members:
#    FANG Anbing
#    LAGO Jenie Marie
#    YANG Zhou

# COMMAND ----------

# DBTITLE 1,Path Setting
# Set all necessary sources here
path_covid_features = "/FileStore/tables/yelp2/parsed_covid_sample.json"
path_yelp_business = "/FileStore/tables/yelp2/parsed_business_sample.json"
path_yelp_checkin = "/FileStore/tables/yelp2/parsed_checkin_sample.json"
path_yelp_review = "/FileStore/tables/parsed_review_sample.json"
path_yelp_tip = "/FileStore/tables/yelp2/parsed_tip_sample.json"
path_yelp_user = "/FileStore/tables/yelp2/parsed_user_sample.json"

# COMMAND ----------

# Imports
from pyspark.sql.functions import count
from pyspark.sql.types import StructField, StructType, StringType, BooleanType
from pyspark.sql.functions import isnan, when, count, col, lower, when, to_timestamp, array_contains
from pyspark.ml.feature import Tokenizer
from pyspark.ml.feature import OneHotEncoder, StringIndexer
from pyspark.ml import Pipeline

# COMMAND ----------

# DBTITLE 1,Processing of covid features
# Load the json file
df_covid_features = spark.read.format("json")\
  .option("inferSchema","true")\
  .load(path_covid_features)

# COMMAND ----------

# Reference: https://www.yelp.com/dataset/documentation/main
df_covid_features.printSchema()

# COMMAND ----------

# Get shape of dataframe
print((df_covid_features.count(), len(df_covid_features.columns)))

# COMMAND ----------

# Check the number of unique business IDs
df_covid_features.select('business_id').distinct().count()

# COMMAND ----------

# Drop duplicates
df_covid_features = df_covid_features.dropDuplicates(['business_id'])
df_covid_features.select('business_id').distinct().count()

# COMMAND ----------

df_covid_features.show(3)

# COMMAND ----------

# Count the number of nulls per column
df_covid_features.select([count(when(col(c).isNull(), c)).alias(c) for c in df_covid_features.columns]).show()

# COMMAND ----------

# Rename all the columns, remove spaces for easier calling in the next steps
df_covid_features = df_covid_features.select([col(c).alias(c.replace(' ', '_')) for c in df_covid_features.columns])

# COMMAND ----------

# Reload View
df_covid_features.createOrReplaceTempView("df_covid_features")

# COMMAND ----------

# Inspect columns that do not look boolean
spark.sql("""
  select distinct Covid_Banner
          from df_covid_features
""").show(5)

# COMMAND ----------

spark.sql("""
  select distinct Temporary_Closed_Until
          from df_covid_features
""").show(5, truncate = False)

# COMMAND ----------

spark.sql("""
  select distinct Virtual_Services_Offered
          from df_covid_features
""").show(15, truncate = False)

# COMMAND ----------

spark.sql("""
  select distinct highlights
          from df_covid_features
""").show(5, truncate = False)

# COMMAND ----------

# change to lower case the columns identified as boolean
df_covid_features = df_covid_features.withColumn("Call_To_Action_enabled",lower(col("Call_To_Action_enabled")))\
                      .withColumn("Grubhub_enabled",lower(col("Grubhub_enabled")))\
                      .withColumn("Request_a_Quote_Enabled",lower(col("Request_a_Quote_Enabled")))\
                      .withColumn("delivery_or_takeout",lower(col("delivery_or_takeout")))

df_covid_features.show(5)

# COMMAND ----------

df_covid_features = df_covid_features.withColumn("Call_To_Action_enabled",col("Call_To_Action_enabled").cast(BooleanType()))\
    .withColumn("Grubhub_enabled",col("Grubhub_enabled").cast(BooleanType())) \
    .withColumn("Request_a_Quote_Enabled",col("Request_a_Quote_Enabled").cast(BooleanType())) \
    .withColumn("delivery_or_takeout",col("delivery_or_takeout").cast(BooleanType()))

# COMMAND ----------

# Count the number of nulls per column, check if cast of all columns successful
df_covid_features.select([count(when(col(c).isNull(), c)).alias(c) for c in df_covid_features.columns]).show()

# COMMAND ----------

# Create _isWithText for the string columns, it was noticed that some columns have FALSE and string values with them. Create a flag for businesses who actually filled out said columns
cols_string = ["Covid_Banner", "Temporary_Closed_Until", "Virtual_Services_Offered", "highlights"]

for col_name in cols_string:
  col_name_new = col_name + "_withText"
  df_covid_features = df_covid_features.withColumn(col_name_new, when(col(col_name)== 'FALSE', 0).otherwise(1))

# COMMAND ----------

# Check values of those columns with actual text
df_covid_features.filter(df_covid_features.Virtual_Services_Offered_withText == 1).show(5)

# COMMAND ----------

# String indexer for Virtual_Services_Offered
lblIndxr = StringIndexer().setInputCol("Virtual_Services_Offered").setOutputCol("VSOInd")

# Perform OneHotEncoding for the Virtual_Services_Offered column
ohee_catv = OneHotEncoder().setInputCol("VSOInd").setOutputCol("VSO_dum")

# Pipeline
pipe_catv = Pipeline(stages=[lblIndxr, ohee_catv])

# COMMAND ----------

df_covid_features = pipe_catv.fit(df_covid_features).transform(df_covid_features)
df_covid_features = df_covid_features.drop("VSOInd")
df_covid_features.show(3)

# COMMAND ----------

# Drop some string columns, To-DO: In the future we can analyze the content of the strings
drop_cols = cols_string

df_covid_features = df_covid_features.drop(*drop_cols)
df_covid_features.printSchema()

# COMMAND ----------

df_covid_features.groupBy("delivery_or_takeout").count().show()

# COMMAND ----------

# Update sql view
df_covid_features.createOrReplaceTempView("df_covid_features")

# COMMAND ----------

df_covid_features.show(5)

# COMMAND ----------

df_covid_features = df_covid_features.withColumn("label",col("delivery_or_takeout").cast("double")).drop("delivery_or_takeout")
df_covid_features = df_covid_features.withColumn("Grubhub_enabled",col("Grubhub_enabled").cast("double"))
df_covid_features = df_covid_features.withColumn("Request_a_Quote_Enabled",col("Request_a_Quote_Enabled").cast("double"))
df_covid_features = df_covid_features.withColumn("Request_a_Quote_Enabled",col("Request_a_Quote_Enabled").cast("double"))
df_covid_features = df_covid_features.withColumn("Call_To_Action_enabled",col("Call_To_Action_enabled").cast("double"))

# COMMAND ----------

df_covid_features.show(5)

# COMMAND ----------

df_covid_features.groupBy("label").count().show()

# COMMAND ----------

# Save covid features to base table
df_final_base = df_covid_features

# COMMAND ----------

df_final_base.createOrReplaceTempView("df_final_base")

# COMMAND ----------

# DBTITLE 1,Data Processing for yelp_academic_dataset_business.json
# Load file
df_business = spark.read.format("json")\
  .option("inferSchema", "true")\
  .option("header","true")\
  .load(path_yelp_business)

# COMMAND ----------

df_business.createOrReplaceTempView("df_business")

# COMMAND ----------

# Check how many of the businesses exist on the covid features
df_business_filtered = spark.sql("""
    SELECT * FROM df_business 
    WHERE business_id IN (
      SELECT business_id from df_covid_features
    )
""")

# COMMAND ----------

print((df_business_filtered.count(), len(df_business_filtered.columns)))

# COMMAND ----------

df_business_filtered.createOrReplaceTempView("df_business_filtered")

# COMMAND ----------

df_business_filtered.groupBy("delivery_mention").count().show()

# COMMAND ----------

business_feature=df_business_filtered[["business_id","categories","city","state","is_open","review_count","stars"]]
business_feature.show(5)

# COMMAND ----------

business_feature.select([count(when(col(c).isNull(), c)).alias(c) for c in business_feature.columns]).show()

# COMMAND ----------

business_feature = business_feature.na.fill(value='Missing')

# COMMAND ----------

business_feature.select([count(when(col(c).isNull(), c)).alias(c) for c in business_feature.columns]).show()

# COMMAND ----------



# COMMAND ----------

#categories,city,state
CatrIndxr = StringIndexer().setInputCol("categories").setOutputCol("categoriesInd")
cityIndxr = StringIndexer().setInputCol("city").setOutputCol("cityInd")
stateIndxr = StringIndexer().setInputCol("state").setOutputCol("stateInd")

#One-hot encoding
ohee_catv = OneHotEncoder(inputCols=["categoriesInd","cityInd","stateInd"],outputCols=["categories_dum","city_dum","state_dum"])
pipe_catv = Pipeline(stages=[CatrIndxr, cityIndxr,stateIndxr, ohee_catv])

# COMMAND ----------

business_feature = pipe_catv.fit(business_feature).transform(business_feature)
business_feature = business_feature.drop("categoriesInd","cityInd","stateInd")
business_feature = business_feature.drop("categories","city","state")

# COMMAND ----------

business_feature = business_feature.withColumnRenamed("business_id", "b_business_id")

# COMMAND ----------

business_feature.show(3)

# COMMAND ----------

business_feature.createOrReplaceTempView("business_feature")

# COMMAND ----------

df_final_base = spark.sql("""
    SELECT f.*, b.*
    from df_final_base f
    LEFT JOIN business_feature b ON f.business_id == b.b_business_id
""")

# COMMAND ----------

df_final_base = df_final_base.na.fill(value=0)

# COMMAND ----------

df_final_base = df_final_base.drop('b_business_id')

# COMMAND ----------

df_final_base.createOrReplaceTempView("df_final_base")

# COMMAND ----------

df_final_base.show(5)

# COMMAND ----------

# DBTITLE 1,Data Processing for yelp_academic_dataset_checkin.json
# Load file
df_checkin = spark.read.format("json")\
  .option("inferSchema", "true")\
  .option("header","true")\
  .load(path_yelp_checkin)

# COMMAND ----------

df_checkin.printSchema()

# COMMAND ----------

df_checkin.show(5)

# COMMAND ----------

df_checkin.createOrReplaceTempView("df_checkin")

# COMMAND ----------

# Get only checkins for 2019
df_checkin_count_2019 = spark.sql("""
  SELECT business_id , count(business_id) as checkin_count
  FROM df_checkin
  where date > '2019-01-01'
  group by business_id
""")

# COMMAND ----------

df_checkin_count_2019.createOrReplaceTempView("df_checkin_count_2019")

# COMMAND ----------

# Get businesses checki, that exist on the covid features table
df_checkin_filtered = spark.sql("""
    SELECT * FROM df_checkin_count_2019 
    WHERE business_id IN (
      SELECT business_id from df_covid_features
    )
""")

# COMMAND ----------

# Get shape of filtered checkin dataframe
print((df_checkin_filtered.count(), len(df_checkin_filtered.columns)))

# COMMAND ----------

df_checkin_filtered.show(5)

# COMMAND ----------

df_checkin_filtered.createOrReplaceTempView("df_checkin_filtered")

# COMMAND ----------

# Merge checkin with basetable
df_final_base = spark.sql("""
    SELECT f.*, c.checkin_count
    from df_final_base f
    LEFT JOIN df_checkin_filtered c ON f.business_id == c.business_id
""")

# COMMAND ----------

print((df_final_base.count(), len(df_final_base.columns)))

# COMMAND ----------

# Count the number of nulls per column
df_final_base.select([count(when(col(c).isNull(), c)).alias(c) for c in df_final_base.columns]).show()

# COMMAND ----------

df_final_base = df_final_base.na.fill(value=0)

# COMMAND ----------

# Count the number of nulls per column after fillna
df_final_base.select([count(when(col(c).isNull(), c)).alias(c) for c in df_final_base.columns]).show()

# COMMAND ----------

df_final_base.createOrReplaceTempView("df_final_base")

# COMMAND ----------

# DBTITLE 1,Data Processing for yelp_academic_dataset_review.json
# Load the file. NOTE: This is 6GB of data, loading may take time
df_review = spark.read.format("json")\
  .option("inferSchema", "true")\
  .option("header","true")\
  .load(path_yelp_review)

# COMMAND ----------

df_review.printSchema()

# COMMAND ----------

df_review.show(3)

# COMMAND ----------

# Convert date to actual timestamp
df_review = df_review.withColumn("date",to_timestamp(col("date"),"yyyy-M-d H:mm:ss"))
df_review.printSchema()

# COMMAND ----------

df_review.show(3)

# COMMAND ----------

df_review.createOrReplaceTempView("df_review")

# COMMAND ----------

spark.sql("SELECT min(date), max(date) FROM df_review").show()

# COMMAND ----------

# With the below min and max result, we filter out recent reviews for 2019 only
# +-------------------+-------------------+
# |          min(date)|          max(date)|
# +-------------------+-------------------+
# |2005-01-24 22:21:29|2019-09-07 17:33:34|
# +-------------------+-------------------+
df_review_filtered = spark.sql("""
    SELECT * FROM df_review 
    WHERE date > '2019-01-01' AND 
    business_id IN (
      SELECT business_id from df_covid_features
    )
""")

# COMMAND ----------

df_review_filtered.count()

# COMMAND ----------

df_review_filtered.createOrReplaceTempView("df_review_filtered")

# COMMAND ----------

# Check minimum data it should show June as the earliest review
spark.sql("SELECT min(date), max(date) FROM df_review_filtered").show()

# COMMAND ----------

df_review_filtered.show(3)

# COMMAND ----------

# Check grouping of star rating
spark.sql("SELECT stars, count(*) FROM df_review_filtered group by stars").show()

# COMMAND ----------

# Flag reviews that contain the "deliver"

# Change text review to lower case
df_review_filtered = df_review_filtered.withColumn("text",lower(col("text")))

# COMMAND ----------

# Find text with delivery and takeout
# Points for improvement: Use proper lemmatization
#search_text = 'delivery' and 'takeout'

df_review_filtered = df_review_filtered.withColumn('delivery_mention', when(col("text").contains('deliver'), 1).otherwise(0))
df_review_filtered = df_review_filtered.withColumn('takeout_mention', when(col("text").contains('takeout'), 1).otherwise(0))

# COMMAND ----------

df_review_filtered.groupBy("delivery_mention").count().show()

# COMMAND ----------

df_review_filtered.groupBy("takeout_mention").count().show()

# COMMAND ----------

df_review_filtered.show(3)

# COMMAND ----------

from pyspark.ml.feature import SQLTransformer

# Create SQL Transformer
sql_transformation = SQLTransformer()\
  .setStatement("""
    SELECT business_id as r_business_id, avg(cool) as avg_cool, sum(cool) as sum_cool,
        avg(funny) as avg_funny, sum(funny) as sum_funny,
        avg(stars) as avg_stars, sum(stars) as sum_stars,
        avg(useful) as avg_useful, sum(useful) as sum_useful,
        sum(delivery_mention) as delivery_mention,
        sum(takeout_mention) as takeout_mention,
        count(*) as review_count
    FROM __THIS__
    GROUP BY business_id
  """)

# COMMAND ----------

df_review_transformed = sql_transformation.transform(df_review_filtered)

# COMMAND ----------

df_review_transformed.show(2)

# COMMAND ----------

# Merge with base table
print(df_final_base.count())
print(df_review_transformed.count())

# COMMAND ----------

df_final_base.createOrReplaceTempView("df_final_base")
df_review_transformed.createOrReplaceTempView("df_review_transformed")

# COMMAND ----------

# Merge with base table
df_final_base = spark.sql("""
    SELECT f.*, r.*
    from df_final_base f
    LEFT JOIN df_review_transformed r ON f.business_id == r.r_business_id
""")

# COMMAND ----------

df_final_base = df_final_base.drop("r_business_id")

# COMMAND ----------

# fill rows with no reviews with 0
df_final_base = df_final_base.na.fill(value=0)

# COMMAND ----------

# Update view
df_final_base.createOrReplaceTempView("df_final_base")

# COMMAND ----------

print((df_final_base.count(), len(df_final_base.columns)))

# COMMAND ----------

# DBTITLE 1,Data Processing for  yelp_academic_dataset_tip.json
# Load file
df_tip = spark.read.format("json")\
  .option("inferSchema", "true")\
  .option("header","true")\
  .load(path_yelp_tip)

# COMMAND ----------

df_tip.show(2)

# COMMAND ----------

df_tip.createOrReplaceTempView("df_tip")

# COMMAND ----------

df_tip_filtered = spark.sql("""
    SELECT * FROM df_tip 
    WHERE business_id IN (
      SELECT business_id from df_covid_features
    )
""")

# COMMAND ----------

# Get shape of filtered tip dataframe
print((df_tip_filtered.count(), len(df_tip_filtered.columns)))

# COMMAND ----------

df_tip_filtered.select("business_id").distinct().count()

# COMMAND ----------

df_tip_filtered.show(2)

# COMMAND ----------

df_tip_filtered.createOrReplaceTempView("df_tip_filtered")

# COMMAND ----------

# Get info of tips
df_tip_filtered_2019 = spark.sql("""
  SELECT business_id , avg(compliment_count) as avg_number_of_compliment , sum(compliment_count) as total_number_of_compliment, count(*) as total_tip_row
  FROM df_tip_filtered
  WHERE date >= '2019-01-01'
  group by business_id
""")

# COMMAND ----------

# To-Do: Get user information

# COMMAND ----------

df_tip_filtered_2019.createOrReplaceTempView("df_tip_filtered_2019")

# COMMAND ----------

df_tip_filtered_2019.select("business_id").distinct().count()

# COMMAND ----------

# Join tip with basetable
df_final_base = spark.sql("""
    SELECT f.*, t.avg_number_of_compliment, t.total_number_of_compliment, t.total_tip_row
    from df_final_base f
    LEFT JOIN df_tip_filtered_2019 t ON f.business_id == t.business_id
""")

# COMMAND ----------

print((df_final_base.count(), len(df_final_base.columns)))

# COMMAND ----------

df_final_base.select([count(when(col(c).isNull(), c)).alias(c) for c in df_final_base.columns]).show()

# COMMAND ----------

df_final_base = df_final_base.na.fill(value=0)

# COMMAND ----------

df_final_base.select([count(when(col(c).isNull(), c)).alias(c) for c in df_final_base.columns]).show()

# COMMAND ----------

df_final_base.createOrReplaceTempView("df_final_base")

# COMMAND ----------

df_final_base.show()

# COMMAND ----------

df_final_base.select([count(when(col(c).isNull(), c)).alias(c) for c in df_final_base.columns]).show()

# COMMAND ----------

# DBTITLE 1,Data Processing for yelp_academic_dataset_user.json
df_user = spark.read.format("json")\
  .option("inferSchema", "true")\
  .option("header","true")\
  .load(path_yelp_user)

# COMMAND ----------

df_user.printSchema()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

from pyspark.ml.feature import RFormula

# COMMAND ----------

# DBTITLE 1,Transformation


# COMMAND ----------



# COMMAND ----------

# Replace final basetable once we have merged the others
basetable_final = df_final_base
#basetable_final = df_covid_features

# COMMAND ----------

basetable_final.show(5)

# COMMAND ----------

# DBTITLE 1,Classification Process
#Create a train and test set with a 70% train, 30% test split
basetable_train, basetable_test = basetable_final.randomSplit([0.7, 0.3],seed=123)

# COMMAND ----------

print(basetable_train.count())
print(basetable_test.count())

# COMMAND ----------

from pyspark.ml.feature import RFormula

trainBig = RFormula(formula="label ~ . - business_id").fit(basetable_final).transform(basetable_final)
train = RFormula(formula="label ~ . - business_id").fit(basetable_train).transform(basetable_train)
test = RFormula(formula="label ~ . - business_id").fit(basetable_test).transform(basetable_test)

# COMMAND ----------

trainBig.show()

# COMMAND ----------

train.show()

# COMMAND ----------

test.show()

# COMMAND ----------

test.select(['features','label']).show(truncate = False)

# COMMAND ----------

print("trainBig nobs: " + str(trainBig.count()))
print("train nobs: " + str(train.count()))
print("test nobs: " + str(test.count()))

# COMMAND ----------

from pyspark.ml.tuning import CrossValidator, ParamGridBuilder
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.classification import LogisticRegression

# COMMAND ----------

train2 = train.select(['features','label'])

# COMMAND ----------

# train = RFormula(formula="label ~ . - business_id").fit(basetable_train).transform(basetable_train)


formula = RFormula(
    formula="label ~ . - business_id - label",
    featuresCol="features")
output = formula.fit(basetable_train).transform(basetable_train)
output.select("features", "label").show()

# COMMAND ----------

output

# COMMAND ----------

# Try no CV
lr_nocv = LogisticRegression()
#Fit the model
lrModel_nocv = lr_nocv.fit(train)

# COMMAND ----------

lrModel_nocv.coefficients

# COMMAND ----------

predictions_lr = lrModel_nocv.transform(test)

# COMMAND ----------

# Source: https://spark.apache.org/docs/2.2.0/mllib-evaluation-metrics.html

# COMMAND ----------

print("Testing set areaUnderROC: " + str(evaluator.evaluate(predictions_lr, {evaluator.metricName: "areaUnderROC"})))

# COMMAND ----------

preds = predictions_lr.select('label','probability').rdd.map(lambda row: (float(row['probability'][1]), float(row['label'])))
points_lr = CurveMetrics(preds).get_curve('roc')

plt.figure()
x_val = [x[0] for x in points_lr]
y_val = [x[1] for x in points_lr]
plt.ylabel('False Positive Rate')
plt.xlabel('True Positive Rate')
plt.title('ROC Curve')
plt.plot(roc['FPR'],roc['TPR'], label='Train', color='red')
plt.plot(x_val, y_val, label = 'Test', color='blue')
plt.plot([0, 1], [0, 1],'r--',color='grey')
plt.legend(loc=4)
print('Training set areaUnderROC: ' + str(trainingSummary.areaUnderROC))

# COMMAND ----------

https://towardsdatascience.com/machine-learning-with-pyspark-and-mllib-solving-a-binary-classification-problem-96396065d2aa

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Logistic Regression
#Define pipeline
lr = LogisticRegression()
pipeline = Pipeline().setStages([lr])

# COMMAND ----------

#Set param grid
params = ParamGridBuilder()\
  .addGrid(lr.regParam, [0.01,0.1])\
  .addGrid(lr.maxIter, [50, 100])\
  .build()

# params = ParamGridBuilder()\
#   .build()

# COMMAND ----------

#Evaluator: uses max(AUC) by default to get the final model
evaluator = BinaryClassificationEvaluator()

# COMMAND ----------

# Cross-validation of entire pipeline
# Set to 10 folds as per project instruction
cv_lr = CrossValidator()\
  .setEstimator(pipeline)\
  .setEstimatorParamMaps(params)\
  .setEvaluator(evaluator)\
  .setNumFolds(10)

# COMMAND ----------

# Use the 
cvModel_lr = cv_lr.fit(train2)

# COMMAND ----------

cvBestPipeline_lr = cvModel_lr.bestModel
cvBestLRModel = cvBestPipeline_lr.stages[-1]._java_obj.parent() #the stages function refers to the stage in the pipelinemodel

print("Best LR model:")
print("** regParam: " + str(cvBestLRModel.getRegParam()))
print("** maxIter: " + str(cvBestLRModel.getMaxIter()))

# COMMAND ----------

preds_lr = cvModel_lr.transform(test)\
  .select("prediction", "label")
preds_lr.show(10)

# COMMAND ----------

#Get model performance on test set
from pyspark.mllib.evaluation import BinaryClassificationMetrics

out = preds_lr.rdd.map(lambda x: (float(x[0]), float(x[1])))
metrics_lr = BinaryClassificationMetrics(out)

print(metrics_lr.areaUnderPR) #area under precision/recall curve
print(metrics_lr.areaUnderROC)#area under Receiver Operating Characteristic curve

# COMMAND ----------

# DBTITLE 1,Random Forest
from pyspark.ml.classification import RandomForestClassifier

#Define pipeline
rfc = RandomForestClassifier()
rfPipe = Pipeline().setStages([rfc])

# COMMAND ----------

from pyspark.ml.classification import RandomForestClassifier

# Try no CV
rf_nocv = RandomForestClassifier(labelCol="label", featuresCol="features", numTrees=500, maxDepth = 5)
#Fit the model
rfModel_nocv = rf_nocv.fit(train)

# COMMAND ----------

predictions_rf = rfModel_nocv.transform(test)

# COMMAND ----------

from pyspark.mllib.evaluation import BinaryClassificationMetrics

#Get model accuracy
evaluator = BinaryClassificationEvaluator()
print("accuracy: " + str(evaluator.evaluate(predictions_rf)))

#Get AUC
metrics_rfc = BinaryClassificationMetrics(predictions_rf.rdd.map(lambda x: (float(x[0]), float(x[1]))))
print("AUC: " + str(metrics_rfc.areaUnderROC))

# COMMAND ----------

print(rfModel_nocv)  # summary only

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

import matplotlib.pyplot as plt
import numpy as np

# COMMAND ----------

trainingSummary = rfModel_nocv.summary

roc = trainingSummary.roc.toPandas()
plt.plot(roc['FPR'],roc['TPR'])
plt.ylabel('False Positive Rate')
plt.xlabel('True Positive Rate')
plt.title('ROC Curve')
plt.show()
print('Training set areaUnderROC: ' + str(trainingSummary.areaUnderROC))

# COMMAND ----------

evaluator = BinaryClassificationEvaluator()
print('Test Area Under ROC', evaluator.evaluate(predictions_rf))

# COMMAND ----------

evaluator = BinaryClassificationEvaluator()
print("Test Area Under ROC: " + str(evaluator.evaluate(predictions_rf, {evaluator.metricName: "areaUnderROC"})))

# COMMAND ----------

# Source: https://stackoverflow.com/questions/52847408/pyspark-extract-roc-curve
from pyspark.mllib.evaluation import BinaryClassificationMetrics

# Scala version implements .roc() and .pr()
# Python: https://spark.apache.org/docs/latest/api/python/_modules/pyspark/mllib/common.html
# Scala: https://spark.apache.org/docs/latest/api/java/org/apache/spark/mllib/evaluation/BinaryClassificationMetrics.html
class CurveMetrics(BinaryClassificationMetrics):
    def __init__(self, *args):
        super(CurveMetrics, self).__init__(*args)

    def _to_list(self, rdd):
        points = []
        # Note this collect could be inefficient for large datasets 
        # considering there may be one probability per datapoint (at most)
        # The Scala version takes a numBins parameter, 
        # but it doesn't seem possible to pass this from Python to Java
        for row in rdd.collect():
            # Results are returned as type scala.Tuple2, 
            # which doesn't appear to have a py4j mapping
            points += [(float(row._1()), float(row._2()))]
        return points

    def get_curve(self, method):
        rdd = getattr(self._java_model, method)().toJavaRDD()
        return self._to_list(rdd)

# COMMAND ----------

# Returns as a list (false positive rate, true positive rate)
preds = predictions_rf.select('label','probability').rdd.map(lambda row: (float(row['probability'][1]), float(row['label'])))
points = CurveMetrics(preds).get_curve('roc')

# COMMAND ----------

plt.figure()
x_val = [x[0] for x in points]
y_val = [x[1] for x in points]
plt.ylabel('False Positive Rate')
plt.xlabel('True Positive Rate')
plt.title('ROC Curve')
plt.plot(roc['FPR'],roc['TPR'], label='Train', color='red')
plt.plot(x_val, y_val, label = 'Test', color='blue')
plt.plot([0, 1], [0, 1],'r--',color='grey')
plt.legend(loc=4)
print('Training set areaUnderROC: ' + str(trainingSummary.areaUnderROC))
#print("Testing set areaUnderROC: " + str(evaluator.evaluate(predictions_rf, {evaluator.metricName: "areaUnderROC"})))

# COMMAND ----------



# COMMAND ----------

#Set param grid
rfParams = ParamGridBuilder()\
  .addGrid(rfc.numTrees, [300, 500])\
  .build()

# COMMAND ----------

rfCv = CrossValidator()\
  .setEstimator(rfPipe)\
  .setEstimatorParamMaps(rfParams)\
  .setEvaluator(BinaryClassificationEvaluator())\
  .setNumFolds(10) 

# COMMAND ----------

#Run cross-validation, and choose the best set of parameters.
rfcModel = rfCv.fit(train)

# COMMAND ----------

cvBestPipeline_rf = rfcModel.bestModel
cvBestRFModel = cvBestPipeline_rf.stages[-1]._java_obj.parent() #the stages function refers to the stage in the pipelinemodel

print("Best RF model:")
print("** NumTrees: " + str(cvBestRFModel.getNumTrees()))

# COMMAND ----------

#Get predictions on the test set
preds_rfc = rfcModel.transform(test)
preds_rfc.show(5)

# COMMAND ----------

import pandas as pd

# Source: https://www.timlrx.com/blog/feature-selection-using-feature-importance-score-creating-a-pyspark-estimator
def ExtractFeatureImp(featureImp, dataset, featuresCol):
    list_extract = []
    for i in dataset.schema[featuresCol].metadata["ml_attr"]["attrs"]:
        list_extract = list_extract + dataset.schema[featuresCol].metadata["ml_attr"]["attrs"][i]
    varlist = pd.DataFrame(list_extract)
    varlist['score'] = varlist['idx'].apply(lambda x: featureImp[x])
    return(varlist.sort_values('score', ascending = False))

# COMMAND ----------

# List down important features
ExtractFeatureImp(cvBestPipeline_rf.stages[-1].featureImportances, preds_rfc, "features").head(10)

# COMMAND ----------

#Get model accuracy
print("accuracy: " + str(evaluator.evaluate(preds_rfc)))

#Get AUC
metrics_rfc = BinaryClassificationMetrics(preds_rfc.rdd.map(lambda x: (float(x[0]), float(x[1]))))
print("AUC: " + str(metrics_rfc.areaUnderROC))

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,Gradient Boosting
from pyspark.ml.classification import GBTClassifier

#Define pipeline
gb = GBTClassifier()
gb_pipeline = Pipeline().setStages([gb])

# COMMAND ----------

#Set param grid
gbParams = ParamGridBuilder()\
  .addGrid(gb.maxDepth, [5, 10])\
  .build()
  
# Increase parameters for final tuning
#gbParams = ParamGridBuilder()\
#  .addGrid(gb.maxDepth, [5, 10])\
#  .addGrid(gb.maxBins, [20, 40])\
#  .addGrid(gb.maxIter, [10, 20])\
#  .build()  

# COMMAND ----------

gbCv = CrossValidator()\
  .setEstimator(gb_pipeline)\
  .setEstimatorParamMaps(gbParams)\
  .setEvaluator(BinaryClassificationEvaluator())\
  .setNumFolds(10) 

# COMMAND ----------

#Run cross-validation, and choose the best set of parameters.
gbModel = gbCv.fit(train)

# COMMAND ----------

cvBestPipeline_gb = gbModel.bestModel
cvBestGBModel = cvBestPipeline_gb.stages[-1]._java_obj.parent() #the stages function refers to the stage in the pipelinemodel

print("Best GB model:")
print("** maxDepth: " + str(cvBestGBModel.getMaxDepth()))

# COMMAND ----------

#Get predictions on the test set
preds_gb = rfcModel.transform(test)
preds_gb.show(5)

# COMMAND ----------

ExtractFeatureImp(cvBestPipeline_gb.stages[-1].featureImportances, preds_gb, "features").head(10)

# COMMAND ----------

#Get model accuracy
print("accuracy: " + str(evaluator.evaluate(preds_gb)))

#Get AUC
metrics_gb = BinaryClassificationMetrics(preds_gb.rdd.map(lambda x: (float(x[0]), float(x[1]))))
print("AUC: " + str(metrics_gb.areaUnderROC))

# COMMAND ----------


